import React from 'react'

const Footer = () => {
    return (
        <div class="bd-footer py-5 mt-5">
        </div>
    )
}

export default Footer