import React from 'react'

export const AboutPage = () => {
    return (
        <div>aboutPage</div>
    )
}

export default AboutPage;