# ME-Server
spring boot based backend server 


folder sturcture
Hyper-Election
  -bin ## hyperledger fabric components binary
  -chaincode ## smart contract https://github.com/x64-tech/Hyper-Election-CC
  -config ## hyperledger fabric config files dir
  -server ## server https://github.com/x64-tech/Hyper-Election-Server
  -test-network ## test network dir of hyperledger fabric
