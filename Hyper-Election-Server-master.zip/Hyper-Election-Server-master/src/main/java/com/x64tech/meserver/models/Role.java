package com.x64tech.meserver.models;

public enum Role {
    ADMIN, USER
}
