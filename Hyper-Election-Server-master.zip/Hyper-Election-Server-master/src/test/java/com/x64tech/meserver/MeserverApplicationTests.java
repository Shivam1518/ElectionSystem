package com.x64tech.meserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MeserverApplicationTests {

	@Test
	void contextLoads() {
	}

}
